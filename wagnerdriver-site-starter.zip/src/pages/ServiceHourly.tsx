import { Link } from 'react-router-dom';
export default function ServiceHourly({ dict, locale }: any) {
  const p = dict?.pages?.hourly ?? {};
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{p.title ?? 'Hourly hire — your driver on standby'}</h1>
      <p className="text-white/80">{p.p1 ?? 'Book by the hour for errands, shopping, medical appointments, or events.'}</p>
      <p className="text-white/80">{p.p2 ?? 'Minimum 2 hours within Gulf Shores/Orange Beach. Flexible routing and stops included.'}</p>
      <Link className="underline" to={`/{locale}/contact`}>{dict?.menu?.contact ?? 'Contact'}</Link>
    </section>
  );
}
