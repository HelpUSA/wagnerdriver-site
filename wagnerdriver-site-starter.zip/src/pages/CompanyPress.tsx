export default function CompanyPress({ dict }: any) {
  const t = dict?.pages?.press ?? {};
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{t.title ?? 'Press'}</h1>
      <p className="text-white/80">{t.p1 ?? 'Content coming soon.'}</p>
    </section>
  );
}
