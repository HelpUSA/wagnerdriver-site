import { Link } from 'react-router-dom';
export default function ServiceLimo({ dict, locale }: any) {
  const p = dict?.pages?.limo ?? {};
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{p.title ?? 'Premium private car service (sedan/SUV)'}</h1>
      <p className="text-white/80">{p.p1 ?? 'While we don’t operate stretch limousines, you’ll enjoy premium private car comfort with professional standards.'}</p>
      <p className="text-white/80">{p.p2 ?? 'Ask about luggage capacity and child seats when you book.'}</p>
      <Link className="underline" to={`/{locale}/contact`}>{dict?.menu?.contact ?? 'Contact'}</Link>
    </section>
  );
}
