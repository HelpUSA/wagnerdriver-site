export default function CompanyBlog({ dict }: any) {
  const t = dict?.pages?.blog ?? {};
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{t.title ?? 'Blog'}</h1>
      <p className="text-white/80">{t.p1 ?? 'Posts coming soon.'}</p>
    </section>
  );
}
