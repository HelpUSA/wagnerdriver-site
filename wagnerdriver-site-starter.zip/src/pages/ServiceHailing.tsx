import { Link } from 'react-router-dom';
export default function ServiceHailing({ dict, locale }: any) {
  const p = dict?.pages?.hailing ?? {};
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{p.title ?? 'On-demand chauffeur hailing (when available)'}</h1>
      <p className="text-white/80">{p.p1 ?? 'Text or call to check immediate availability. Response is usually faster by phone or SMS within local hours.'}</p>
      <p className="text-white/80">{p.p2 ?? 'Great for last-minute pickups around Gulf Shores and nearby areas.'}</p>
      <Link className="underline" to={`/{locale}/contact`}>{dict?.menu?.contact ?? 'Contact'}</Link>
    </section>
  );
}
