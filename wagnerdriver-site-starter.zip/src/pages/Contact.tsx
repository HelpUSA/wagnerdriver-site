export default function Contact({ dict, phone, sms, email }: any) {
  const c = dict?.contact ?? {};
  const phoneE164 = phone ?? dict?.contacts?.phoneE164 ?? '+12516778459';
  const smsE164 = sms ?? dict?.contacts?.smsE164 ?? phoneE164;
  const mail = email ?? dict?.contacts?.email ?? 'wagnermrc@gmail.com';

  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{c.title ?? 'Contact'}</h1>
      <p className="text-white/80">{c.intro ?? 'Talk by phone, SMS or WhatsApp.'}</p>
      <ul className="space-y-1">
        <li>Phone: <a className="underline" href={`tel:${phoneE164}`}>{phoneE164}</a></li>
        <li>Email: <a className="underline" href={`mailto:${mail}`}>{mail}</a></li>
        <li>SMS: <a className="underline" href={`sms:${smsE164}`}>Send SMS</a></li>
      </ul>
    </section>
  );
}
