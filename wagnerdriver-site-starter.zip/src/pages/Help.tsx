export default function Help({ dict }: any) {
  const p = dict?.pages?.help ?? {};
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{p.title ?? 'Help & FAQs'}</h1>
      <div>
        <p className="font-semibold">{p.q1 ?? 'Question 1'}</p>
        <p className="text-white/80">{p.a1 ?? ''}</p>
      </div>
      <div>
        <p className="font-semibold">{p.q2 ?? 'Question 2'}</p>
        <p className="text-white/80">{p.a2 ?? ''}</p>
      </div>
      <div>
        <p className="font-semibold">{p.q3 ?? 'Question 3'}</p>
        <p className="text-white/80">{p.a3 ?? ''}</p>
      </div>
    </section>
  );
}
