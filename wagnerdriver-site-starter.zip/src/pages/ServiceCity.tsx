import { Link } from 'react-router-dom';
export default function ServiceCity({ dict, locale }: any) {
  const p = dict?.pages?.city ?? {};
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{p.title ?? 'City-to-City rides around Coastal Alabama'}</h1>
      <p className="text-white/80">{p.p1 ?? 'Comfortable direct trips between Gulf Shores, Mobile, Fairhope, and Pensacola.'}</p>
      <p className="text-white/80">{p.p2 ?? 'Pricing is distance-based with transparent quotes before you confirm.'}</p>
      <Link className="underline" to={`/{locale}/contact`}>{dict?.menu?.contact ?? 'Contact'}</Link>
    </section>
  );
}
