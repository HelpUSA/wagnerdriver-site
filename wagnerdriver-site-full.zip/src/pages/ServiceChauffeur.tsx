import { Link } from 'react-router-dom';
export default function ServiceChauffeur({ dict, locale }: any) {
  const p = dict?.pages?.chauffeur ?? {}
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{p.title ?? 'Private chauffeur service — single-vehicle'}</h1>
      <p className="text-white/80">{p.p1 ?? 'Personalized, reliable service operated by Wagner using his own vehicle.'}</p>
      <p className="text-white/80">{p.p2 ?? 'Perfect for travelers who value direct communication and consistent quality.'}</p>
      <Link className="underline" to={`/${locale}/contact`}>
        {dict?.menu?.contact ?? 'Contact'}
      </Link>
    </section>
  );
}
