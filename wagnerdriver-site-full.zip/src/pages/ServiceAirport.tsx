import { Link } from 'react-router-dom';
export default function ServiceAirport({ dict, locale }: any) {
  const p = dict?.pages?.airport ?? {}
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{p.title ?? 'Airport transfers (GUF / PNS / MOB)'}</h1>
      <p className="text-white/80">{p.p1 ?? 'Stress-free pickups and drop-offs with flight tracking and complimentary wait time.'}</p>
      <p className="text-white/80">{p.p2 ?? 'Ideal for vacations and business travel around Gulf Shores, Orange Beach, Foley, Mobile and Pensacola.'}</p>
      <Link className="underline" to={`/${locale}/contact`}>
        {dict?.menu?.contact ?? 'Contact'}
      </Link>
    </section>
  );
}
