import { Link } from 'react-router-dom';
export default function ForChauffeurs({ dict, locale }: any) {
  const t = dict?.pages?.forChauffeurs ?? {
    title: 'For Chauffeurs',
    p1: 'Partner with Wagner Driver. Consistent standards and clear communication.',
    p2: 'Send your details by email to start the conversation.'
  };
  return (
    <section className="pt-24 container mx-auto px-6 space-y-4">
      <h1 className="text-2xl font-bold">{t.title}</h1>
      <p className="text-white/80">{t.p1}</p>
      <p className="text-white/80">{t.p2}</p>
      <Link className="underline" to={`/${locale}/contact`}>
        {dict?.menu?.contact ?? 'Contact'}
      </Link>
    </section>
  );
}
